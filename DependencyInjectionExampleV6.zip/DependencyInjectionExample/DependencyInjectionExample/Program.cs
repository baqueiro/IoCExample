﻿using Financial;
using Financial.Implementations;
using Financial.Interfaces;
using IoCLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DependencyInjectionExample
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                // Simple IoC
                SimpleIoC();

                // Factory
                Factory();

                // Nasdaq
                IoCLibraryExample1();

                // IPC
                IoCLibraryExample2();

                // AutoRegister
                IoCAutoRegister();

                // AutoRegister bootstrapper
                IoCBootstrapper();

                Console.WriteLine();
                Console.WriteLine("Press any key to exit");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }

        /// <summary>
        /// Simple IoC example
        /// </summary>
        private static void SimpleIoC()
        {
            IMarketEquity marketEquity = new NasdaqMarket();
            IMarket market = new Market();
            ICalculator instance = new MarketEquityCalculator(marketEquity, market);

            Console.WriteLine($"SimpleIoC example: {instance.FirstEquityGetItem()}");
        }

        /// <summary>
        /// Factory example
        /// </summary>
        private static void Factory()
        {
            var factory = new FinancialFactory();
            ICalculator instance = new MarketEquityCalculator(factory.MarketEquity, factory.Market);

            Console.WriteLine($"Factory example: {instance.FirstEquityGetItem()}");
        }

        /// <summary>
        /// Example 1 for register
        /// </summary>
        private static void IoCLibraryExample1()
        {
            var container = new IoCContainer();

            container.Register<ICalculator, MarketEquityCalculator>();
            container.Register<IMarket, Market>();
            container.Register<IMarketEquity, NasdaqMarket>();

            ICalculator instance = container.Resolve<ICalculator>();

            Console.WriteLine($"Example 1 example: {instance.FirstEquityGetItem()}");
        }

        /// <summary>
        /// Example 2 for register
        /// </summary>
        private static void IoCLibraryExample2()
        {
            var container = new IoCContainer();

            container.Register<ICalculator, MarketEquityCalculator>();
            container.Register<IMarket, Market>();
            container.Register<IMarketEquity, IPCMarket>();

            ICalculator instance = container.Resolve<ICalculator>();

            Console.WriteLine($"Example 2 example: {instance.FirstEquityGetItem()}");
        }

        /// <summary>
        /// Autoregister example
        /// We need to define first IMarketEquity before of autoregister,
        /// because has two possibles implementations: IPCMarket y NasdaqMarket
        /// </summary>
        private static void IoCAutoRegister()
        {
            var container = new IoCContainer();
            
            container.Register<IMarketEquity, IPCMarket>();
            container.AutoRegister<ICalculator>();

            ICalculator instance = container.Resolve<ICalculator>();

            Console.WriteLine($"Autoregister example: {instance.FirstEquityGetItem()}");
        }

        /// <summary>
        /// Bootstrapper example
        /// </summary>
        private static void IoCBootstrapper()
        {
            ICalculator instance = new Bootstrapper().RegisterServices();

            Console.WriteLine($"Bootstrapper example: {instance.FirstEquityGetItem()}");
        }
    }
}
