﻿using Financial;
using Financial.Implementations;
using Financial.Interfaces;
using IoCLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DependencyInjectionExample
{
    /// <summary>
    /// Bootstrapper
    /// </summary>
    public class Bootstrapper
    {
        public ICalculator RegisterServices()
        {
            var container = new IoCContainer();

            container.Register<ICalculator, MarketEquityCalculator>();
            container.Register<IMarket, Market>();
            container.Register<IMarketEquity, NasdaqMarket>();

            ICalculator instance = container.Resolve<ICalculator>();
            
            return instance;
        }
    }
}
