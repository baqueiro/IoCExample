﻿using Financial.Implementations;
using Financial.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DependencyInjectionExample
{
    /// <summary>
    /// Factory class
    /// </summary>
    public class FinancialFactory
    {
        public IMarketEquity MarketEquity { get; set; } = new NasdaqMarket();
        
        public IMarket Market { get; set; } = new Market();
    }
}
