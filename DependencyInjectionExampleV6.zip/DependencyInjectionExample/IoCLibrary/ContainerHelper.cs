﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace IoCLibrary
{
    /// <summary>
    /// Helper for container
    /// </summary>
    internal class ContainerHelper
    {
        /// <summary>
        /// ConstructorInfo
        /// </summary>
        private ConstructorInfo ConstructorInfo { get; set; }

        /// <summary>
        /// Ignored types for finding container
        /// </summary>
        public List<Type> IgnoredTypes { get; set; }

        /// <summary>
        /// Constructor for container helper
        /// </summary>
        /// <param name="type">Type of interfaz</param>
        public ContainerHelper(Type type)
        {
            ConstructorInfo[] constructors;

            if (type.IsInterface)
            {
                var typeList = AssemblyHelper.ConcreteClassTypesGetList();

                var implementedType = typeList.First(p => type.IsAssignableFrom(p));

                constructors = implementedType.GetConstructors(BindingFlags.Instance | BindingFlags.Public);
            }
            else
            {
                constructors = type.GetConstructors(BindingFlags.Instance | BindingFlags.Public);
            }

            if (constructors == null || constructors.Count() != 1)
                throw new Exception("Error: For this example, the classes need to have only one constructor");

            ConstructorInfo = constructors.First();
        }
        
        /// <summary>
        /// Set a list of types that not use in autoregister
        /// </summary>
        /// <param name="list"></param>
        internal void SetIgnoredTypes(List<Type> list)
        {
            IgnoredTypes = list;
        }
        
        /// <summary>
        /// Calls ConstructorInfo Invoke
        /// </summary>
        /// <param name="instancesList"></param>
        /// <returns></returns>
        internal object Invoke(object[] instancesList)
        {
            return ConstructorInfo.Invoke(instancesList);
        }

        /// <summary>
        /// Get instance list in same order that constructor parameters
        /// </summary>
        /// <param name="container"></param>
        /// <returns></returns>
        internal object[] GetInstances(Dictionary<Type, Type> container)
        {
            var constructorParams = ConstructorInfo.GetParameters();

            var instancesTypesOrdered = from i in constructorParams
                                        join o in container on i.ParameterType equals o.Key
                                        select o.Value;

            var instancesList = instancesTypesOrdered.Select(p => Activator.CreateInstance(p)).ToArray();

            return instancesList;
        }

        /// <summary>
        /// Get container for autoregister
        /// </summary>
        /// <returns></returns>
        internal Dictionary<Type, Type> GetAutoregisterContainer()
        {
            var constructorParams = ConstructorInfo.GetParameters().Select(p => p.ParameterType).Except(IgnoredTypes);
            var typeList = AssemblyHelper.ConcreteClassTypesGetList();
            
            return constructorParams.ToDictionary(x => x, x => typeList.First(p => x.IsAssignableFrom(p)));
        }

        /// <summary>
        /// Find if interfaces from constructor have 0 or 2 or more instances
        /// </summary>
        internal void ValidateAutoregister()
        {
            var constructorParams = ConstructorInfo.GetParameters().Select(p => p.ParameterType).Except(IgnoredTypes);
            var typeList = AssemblyHelper.ConcreteClassTypesGetList();

            var noImplementation = constructorParams.FirstOrDefault(x => typeList.Count(p => x.IsAssignableFrom(p)) == 0);

            if (noImplementation != default(Type))
            {
                throw new Exception($"Autoregister: No exists implementation for {noImplementation.Name}");
            }

            var twoOrMoreImplementations = constructorParams.FirstOrDefault(x => typeList.Count(p => x.IsAssignableFrom(p)) == 2);

            if (twoOrMoreImplementations != default(Type))
            {
                throw new Exception($"Autoregister: Exists two or more implementation for {twoOrMoreImplementations.Name}. Register one of them.");
            }
        }
    }
}
