﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace IoCLibrary
{
    /// <summary>
    /// Simple IoC for knowledge purposes
    /// </summary>
    public class IoCContainer
    {
        /// <summary>
        /// Internal dictionary that saves interfaces and implementations
        /// </summary>
        private Dictionary<Type, Type> container { get; set; } = new Dictionary<Type, Type>();

        #region AutoRegister

        /// <summary>
        /// AutoRegister all interfaces from <paramref name="T"/>
        /// If exists two or more implementations, we need to register one of them before
        /// calling this method
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public void AutoRegister<T>()
        {
            ContainerHelper helper = new ContainerHelper(typeof(T));

            helper.SetIgnoredTypes(container.Keys.ToList());

            helper.ValidateAutoregister();

            var helperContainerData = helper.GetAutoregisterContainer();

            foreach(var key in helperContainerData.Keys)
            {
                if (!container.ContainsKey(key))
                {
                    container.Add(key, helperContainerData[key]);
                }
            }
        }

        #endregion

        #region Register

        /// <summary>
        /// Register <paramref name="TFrom"/> and <paramref name="TTo"/> in internal container
        /// </summary>
        /// <typeparam name="TFrom">Interface</typeparam>
        /// <typeparam name="TTo">Concrete class</typeparam>
        public void Register<TFrom, TTo>()
        {
            ValidateRegister<TFrom, TTo>();

            container.Add(typeof(TFrom), typeof(TTo));
        }

        /// <summary>
        /// Validate register
        /// </summary>
        /// <typeparam name="TFrom"></typeparam>
        /// <typeparam name="TTo"></typeparam>
        private void ValidateRegister<TFrom, TTo>()
        {
            if (!typeof(TFrom).IsAssignableFrom(typeof(TTo)))
            {
                throw new Exception($"{typeof(TFrom).Name} is not assignable from {typeof(TTo).Name}");
            }

            if (container.ContainsKey(typeof(TFrom)))
            {
                throw new Exception($"{typeof(TFrom).Name} can't be implemented twice in register. Second implementation class: {typeof(TTo).Name}");
            }
        }

        #endregion

        #region Resolve

        /// <summary>
        /// Instance all interfaces defined in <paramref name="T"/> from internal container
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public T Resolve<T>()
        {
            ContainerHelper helper = new ContainerHelper(typeof(T));

            object[] instancesList = helper.GetInstances(container);

            return (T)helper.Invoke(instancesList);
        }

        #endregion
    }
}
