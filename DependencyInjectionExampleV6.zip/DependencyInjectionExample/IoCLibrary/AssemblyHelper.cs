﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace IoCLibrary
{
    /// <summary>
    /// Functionality from assembly
    /// </summary>
    internal class AssemblyHelper
    {
        private const string AssemblyMicrosoft = "Microsoft";

        private const string AssemblySystem = "System";

        private const string AssemblyMscorlib = "mscorlib";

        private const string AssemblyVshost32 = "vshost32";

        /// <summary>
        /// Find all possible concrete classes in the project
        /// </summary>
        /// <returns></returns>
        internal static IEnumerable<Type> ConcreteClassTypesGetList()
        {
            return AppDomain.CurrentDomain.GetAssemblies()
                    .Where(p => !IgnoreSystemAsemblies(p))
                    .SelectMany(p => p.GetReferencedAssemblies()).Select(p => Assembly.Load(p))
                    .Where(p => !IgnoreSystemAsemblies(p)) // yes, twice!
                    .SelectMany(p => p.GetTypes())
                    .Where(x => !x.Attributes.HasFlag(TypeAttributes.Abstract)
                                       && x.Attributes.HasFlag(TypeAttributes.Public)
                                       && !x.Attributes.HasFlag(TypeAttributes.NestedPrivate)
                                       && x.IsClass
                                       && !x.IsInterface
                                       && !x.IsAbstract);
        }

        /// <summary>
        /// Ignored assemblies
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        private static bool IgnoreSystemAsemblies(Assembly p)
        {
            return p.FullName.Contains(AssemblyMicrosoft)
                    || p.FullName.Contains(AssemblySystem)
                    || p.FullName.Contains(AssemblyMscorlib)
                    || p.FullName.Contains(AssemblyVshost32);
        }
    }
}
