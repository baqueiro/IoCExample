﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Financial.Interfaces
{
    /// <summary>
    /// Interface examlpe of market
    /// </summary>
    public interface IMarket
    {
        List<string> MarketsGetList();
    }
}
