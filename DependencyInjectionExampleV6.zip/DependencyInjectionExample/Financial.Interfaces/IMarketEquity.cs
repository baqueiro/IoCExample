﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Financial.Interfaces
{
    /// <summary>
    /// Interface example for equity market
    /// </summary>
    public interface IMarketEquity
    {
        List<string> EquityGetList();
    }
}
